from .linear_regression import Linear
from .logistic_regression import Logistic